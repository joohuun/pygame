import pygame

class Tile(pygame.sprite.Sprite): #타일 클래스(집단) 생성
    def __init__(self,pos,size): # 각 타일(객체)의 위치, 크기 속성 설정
        super().__init__() # 다른 클래스의 속성을 불러옴
        self.image = pygame.Surface((size, size)) #셀프 이미지 설정 (x,y)사이즈
        self.image.fill('grey') # 타일 색
        self.rect = self.image.get_rect(topleft = pos) #셀프 사각형 위치 설정

    def update(self, x_shift):  # 축이동
        self.rect.x += x_shift


