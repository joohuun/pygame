import pygame
from support_1 import import_folder

class Tile(pygame.sprite.Sprite): #타일 클래스(집단) 생성
    # def __init__(self,pos,size): # 각 타일(객체)의 위치, 크기 속성 설정
    #     super().__init__() # 다른 클래스의 속성을 불러옴
    #     self.image = pygame.Surface((size, size)) #셀프 이미지 설정 (x,y)사이즈
    #     self.image.fill('grey') # 타일 색
    #     self.rect = self.image.get_rect(topleft = pos) #셀프 사각형 위치 설정
    #
    # def update(self, x_shift):  # 축이동
    #     self.rect.x += x_shift
    def __init__(self,size,x,y):
        super().__init__()
        self.image = pygame.Surface((size,size))
        self.rect = self.image.get_rect(topleft = (x,y))

    def update(self,shift):
        self.rect.x += shift

class StaticTile(Tile): # grass step3
    def __init__(self,size,x,y,surface):
        super().__init__(size,x,y)
        self.image = surface

class Crate(StaticTile): # crate step3
    def __init__(self,size,x,y):
        super().__init__(size,x,y,pygame.image.load('../graphics/terrain/crate.png').convert_alpha())
        ofset_y = y +size # 상자 바닥에 붙여버리기
        self.rect = self.image.get_rect(bottomleft = (x,ofset_y))

class AnimatedTile(Tile): # coins step3
    def __init__(self,size,x,y,path):
        super().__init__(size,x,y)
        self.frames = import_folder(path)
        self.frame_index = 0
        self.image = self.frames[self.frame_index]

    def animate(self):
        self.frame_index += 0.15
        if self.frame_index >= len(self.frames):
            self.frame_index = 0
        self.image = self.frames[int(self.frame_index)]

    def update(self,shift):
        self.animate()
        self.rect.x += shift

class Coin(AnimatedTile):
    def __init__(self,size,x,y,path):
        super().__init__(size,x,y,path)
        center_x = x + int(size/2)
        center_y = y + int(size/2)
        self.rect = self.image.get_rect(center = (center_x,center_y))




